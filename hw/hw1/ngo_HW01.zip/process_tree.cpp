#include <iostream>
#include <unistd.h>    // declare fork(), getpid(): child's process id, getppid(): parent's process id
#include <sys/wait.h>  // declare wait()
#include <sys/types.h> // declare pid_t: return type of fork()

using namespace std;

void print_process_info(string name)
{
    cout << "Process: " << name << endl;
    cout << "PID: " << getpid() << endl;
    cout << "Parent PID: " << getppid() << endl;
    cout << endl;
}

void print_simulated_work(string name)
{
    for (int i = 1; i <= 3; i++)
    {
        cout << name << " working... step " << i << endl;
        sleep(1);
    }
    cout << name << " finished." << endl;
    cout << endl;
}

int main()
{
    print_process_info("Parent");

    pid_t childA = fork();                  // Create Child A
    if (childA == 0)
    {
        print_process_info("Child A");

        pid_t gA1 = fork();
        if (gA1 == 0)
        {
            print_process_info("Grandchild A1");
            print_simulated_work("Grandchild A1");
            return 0;
        }

        pid_t gA2 = fork();
        if (gA2 == 0)
        {
            print_process_info("Grandchild A2");
            print_simulated_work("Grandchild A2");
            return 0;
        }

        // child A waits for both grandchildren to finish 
        waitpid(gA1, NULL, 0);
        waitpid(gA2, NULL, 0);

        // then child A works
        print_simulated_work("Child A");

        return 0;
    }
    else if (childA < 0)
    {
        cout << "Fork error for Child A" << endl;
        return 1;
    }

    pid_t childB = fork();
    if (childB == 0)
    {
        print_process_info("Child B");

        pid_t gB1 = fork();
        if (gB1 == 0)
        {
            print_process_info("Grandchild B1");
            print_simulated_work("Grandchild B1");
            return 0;
        }

        // child B waits for Grandchild B1 first
        waitpid(gB1, NULL, 0);

        // then child B works
        print_simulated_work("Child B");

        return 0;
    }
    else if (childB < 0)
    {
        cout << "Fork error for Child B" << endl;
        return 1;
    }

    // parent waits for Child A and Child B
    waitpid(childA, NULL, 0);
    waitpid(childB, NULL, 0);

    cout << "All child processes completed successfully." << endl;
    cout << "Parent finished." << endl;

    return 0;
}

